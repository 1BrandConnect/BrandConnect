<?php

    if( !defined( 'TATSU_HEADER_CPT_NAME' ) ) {
        define( 'TATSU_HEADER_CPT_NAME', 'tatsu_header' );
    }

    if( !defined( 'TATSU_FOOTER_CPT_NAME' ) ) {
        define( 'TATSU_FOOTER_CPT_NAME', 'tatsu_footer' );
    }