<?php
/**
 * Default Footer Builder Template
 */

get_header(); 
get_footer(); 
?>